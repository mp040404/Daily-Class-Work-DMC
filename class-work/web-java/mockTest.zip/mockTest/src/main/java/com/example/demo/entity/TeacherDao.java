package com.example.demo.entity;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TeacherDao extends JpaRepository<Teacher, Integer> {

	List<Teacher> findByDept_Deptid(int deptid);

}
