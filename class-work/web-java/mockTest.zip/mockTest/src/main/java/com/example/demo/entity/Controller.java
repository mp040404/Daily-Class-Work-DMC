package com.example.demo.entity;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



//@RequestMapping(value = "")
@RestController
public class Controller {

	@Autowired
	private DeptDao deptDao;
	
	@Autowired
	private TeacherDao teacherDao;
	
	//Display All Dept
	@GetMapping("/dept")
	public List<Dept> findAll(){
		List<Dept> list = deptDao.findAll(); 
		return list;
		
	}
	
	//Add Dipt
	@PostMapping("/dept")
	public Dept addDept(@RequestBody Dept d) {
		return deptDao.save(d);
		
	}
	
	//Get all teachers in a department 
	@GetMapping("/dept/{deptid}")
	public List<Teacher> findall(@PathVariable("deptid") int deptid){
		return teacherDao.findByDept_Deptid(deptid);
		
	}
	
	//Add new teacher under a department 
	@PostMapping("/dept/{deptid}/addteacher")
	public Teacher addTeacher(@PathVariable("deptid") int deptid,@RequestBody Teacher t) {
		
		Dept d =deptDao.findById(deptid).orElse(null);
		t.setDept(d);
		return teacherDao.save(t);
		
	}
	
	@PutMapping("/dept/upsal/{id}")
	public Teacher updateSalary(@PathVariable("id") int id ,@RequestBody Teacher t ) {
		Teacher existing = teacherDao.findById(id).orElse(null);

		if (existing != null) {
			existing.setSalary(t.getSalary());
			teacherDao.save(existing);
		}

		return null;
	}
	
	@DeleteMapping("/dept/{id}")
	public String Delete(@PathVariable("id") int id) {
		deptDao.deleteById(id);
		
		return "Department deleted successfully with id: " + id;
	}
	
}
